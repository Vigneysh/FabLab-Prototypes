                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3062271
Skyrim skull Dragon wall Trophy by RaffoSan is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

adapted the original mesh from the base game, I really like this not high low poly shape.
the files are position for best printing, sad to say this model needs a bit of supports

needed 2 m5 30mm screws to lock it better to the wall plate, but also simple glue can work.
planning to add 2 printable pins to use isntead of the bolt

studied to be printed hollow with 3-4 perimeters

filament:
hobbyking PLA metallic gold http://bit.ly/2MFTajG

WANT MORE? I can,
just support me, share ur make or ur interest and I'll be glad to make somethin for u.

NOTICE: each of my works is also printed by me and tested in without defects on mounting, not just a bare 3d file without the right tolerances

if u want to support me buy me a coffee or two : https://www.paypal.me/raffoslab